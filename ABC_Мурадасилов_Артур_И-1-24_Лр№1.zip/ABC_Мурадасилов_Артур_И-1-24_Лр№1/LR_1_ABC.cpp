#include <iostream>
#include <cmath>
#include <Windows.h>
using namespace std;

int main()
{
	SetConsoleCP(1251); // русский язык
	SetConsoleOutputCP(1251); // русский язык



	string a;
	int b;

	cout << "Введите систему счисления: "; //      16 c/c
	cin >> b;

	cout << "Введите число: ";  //                  3A7
	cin >> a;


	string n;
	int r = 0;

	int i = a.size() - 1;
	int st = 0;



	//cout << i;


	int sum = 0;
	



	for (; i > -1; i--) {

		n = { a[i] }; //значение до перевода

	//cout << n << "\n";


	
		if (n == "0") {
			r = 0;
		}
		else if (n == "1") {
			r = 1;
		}
		else if (n == "2") {
			r = 2;
		}
		else if (n == "3") {
			r = 3;
		}
		else if (n == "4") {
			r = 4;
		}
		else if (n == "5") {
			r = 5;
		}
		else if (n == "6") {
			r = 6;
		}
		else if (n == "7") {
			r = 7;
		}
		else if (n == "8") {
			r = 8;
		}
		else if (n == "9") {
			r = 9;
		}
		else if (n == "A") {
			r = 10;
		}
		else if (n == "B") {
			r = 11;
		}
		else if (n == "C") {
			r = 12;
		}
		else if (n == "D") {
			r = 13;
		}
		else if (n == "E") {
			r = 14;
		}
		else if (n == "F") {
			r = 15;
		};

		sum += r * pow(b, st);
		st++;





		//cout << r;


	};

cout << "Число в десятичной системе счисления: " << sum;


	

	return 0;
};

